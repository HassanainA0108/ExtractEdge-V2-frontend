import { useState, ChangeEvent, FormEvent } from 'react';

interface ExtractedData {
  [key: string]: string;
}

const App = () => {
  const [file, setFile] = useState<File | null>(null);
  const [userParameters, setUserParameters] = useState<string>('');
  const [extractedData, setExtractedData] = useState<ExtractedData | null>(null);
  const [rawResponse, setRawResponse] = useState<string>('');
  const [pdfImages, setPdfImages] = useState<string[]>([]);
  const [selectedPage, setSelectedPage] = useState<number>(0);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [zoomLevel, setZoomLevel] = useState<number>(1);

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFile(e.target.files[0]);
      setExtractedData(null);
      setRawResponse('');
      setPdfImages([]);
      setSelectedPage(0);
      setErrorMsg('');
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!file || !userParameters) return;
    
    setLoading(true);
    setErrorMsg('');
    const formData = new FormData();
    formData.append('file', file);
    formData.append('user_parameters', userParameters);

    try {
      const res = await fetch('http://localhost:8000/upload', {
        method: 'POST',
        body: formData,
      });
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.detail || 'Upload failed');
      }
      const data = await res.json();
      setExtractedData(data.extracted_data);
      setRawResponse(data.raw_response);
      setPdfImages(data.pdf_images || []);
    } catch (error: any) {
      setErrorMsg(error.message);
    } finally {
      setLoading(false);
    }
  };

  const generateCSV = (data: ExtractedData) => {
    const header = "Parameter,Value\n";
    const rows = Object.entries(data)
      .map(([key, value]) => `"${key}","${value}"`)
      .join("\n");
    return header + rows;
  };

  const downloadFile = (content: string, filename: string, mimeType: string) => {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleCellChange = (key: string, value: string) => {
    if (extractedData) {
      setExtractedData({ ...extractedData, [key]: value });
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col items-center p-4">
      <h1 className="text-4xl font-bold mb-6">Extract Edge</h1>
      <form onSubmit={handleSubmit} className="w-full max-w-2xl bg-gray-800 p-6 rounded shadow mb-6">
        <label className="block mb-4">
          <span className="text-lg font-medium">Upload PDF/TXT/DOCX File</span>
          <input
            type="file"
            accept=".pdf,.txt,.docx"
            onChange={handleFileChange}
            className="mt-2 block w-full text-sm text-gray-300
              file:mr-4 file:py-2 file:px-4
              file:rounded file:border-0
              file:text-sm file:font-semibold
              file:bg-gray-700 file:text-white
              hover:file:bg-gray-600"
          />
        </label>
        <label className="block mb-4">
          <span className="text-lg font-medium">Enter Parameters to Extract</span>
          <input
            type="text"
            value={userParameters}
            onChange={(e) => setUserParameters(e.target.value)}
            placeholder="e.g., Invoice Number, Invoice Date, Total Amount"
            className="mt-2 block w-full p-2 rounded bg-gray-700 text-white"
          />
        </label>
        <button
          type="submit"
          disabled={!file || loading || !userParameters}
          className="w-full bg-green-600 hover:bg-green-500 text-white py-2 px-4 rounded font-semibold"
        >
          {loading ? 'Processing...' : 'Upload and Process'}
        </button>
      </form>
      {errorMsg && (
        <div className="mt-4 text-red-500">
          <p>Error: {errorMsg}</p>
        </div>
      )}
      {(extractedData && pdfImages.length > 0) && (
        <div className="mt-6 w-full max-w-6xl flex flex-col md:flex-row gap-6">
          {/* Left Column: Editable Extracted Data & Downloads */}
          <div className="flex-1">
            <h2 className="text-2xl font-bold mb-4">Retrieved Information</h2>
            <table className="min-w-full divide-y divide-gray-700 mb-4">
              <tbody className="bg-gray-800">
                {Object.entries(extractedData).map(([key, value]) => (
                  <tr key={key}>
                    <td className="px-4 py-2 font-medium">{key}</td>
                    <td className="px-4 py-2">
                      <input
                        type="text"
                        value={value}
                        onChange={(e) => handleCellChange(key, e.target.value)}
                        className="bg-gray-700 text-white p-1 rounded w-full"
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="flex gap-4 mb-4">
              <button
                onClick={() =>
                  downloadFile(JSON.stringify(extractedData, null, 4), "response.json", "application/json")
                }
                className="bg-blue-600 hover:bg-blue-500 px-4 py-2 rounded"
              >
                Download JSON
              </button>
              <button
                onClick={() => downloadFile(generateCSV(extractedData), "extracted_data.csv", "text/csv")}
                className="bg-blue-600 hover:bg-blue-500 px-4 py-2 rounded"
              >
                Download CSV
              </button>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-2">Raw Response</h3>
              <pre className="bg-gray-700 p-4 rounded overflow-x-auto text-sm">{rawResponse}</pre>
            </div>
          </div>
          {/* Right Column: PDF Viewer with Clickable Page Numbers */}
          <div className="flex-1">
            <h2 className="text-2xl font-bold mb-4">PDF Viewer</h2>
            <div className="mb-4 flex flex-wrap gap-2">
              {pdfImages.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedPage(index)}
                  className={`px-3 py-1 rounded ${
                    index === selectedPage ? "bg-blue-600" : "bg-gray-700 hover:bg-gray-600"
                  }`}
                >
                  {index + 1}
                </button>
              ))}
            </div>
            <div className="mb-4 flex gap-2">
              <button
                onClick={() => setZoomLevel(zoomLevel + 0.1)}
                className="bg-blue-600 hover:bg-blue-500 px-4 py-2 rounded"
              >
                Zoom In
              </button>
              <button
                onClick={() => setZoomLevel(zoomLevel - 0.1)}
                className="bg-blue-600 hover:bg-blue-500 px-4 py-2 rounded"
              >
                Zoom Out
              </button>
            </div>
            <div className="overflow-auto">
              <img
                src={`data:image/png;base64,${pdfImages[selectedPage]}`}
                alt={`PDF Page ${selectedPage + 1}`}
                style={{ transform: `scale(${zoomLevel})` }}
                className="w-full rounded shadow-lg"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
